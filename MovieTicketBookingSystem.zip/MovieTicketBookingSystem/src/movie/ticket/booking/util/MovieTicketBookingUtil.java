package movie.ticket.booking.util;

public class MovieTicketBookingUtil {
	
	public static final int PLATINUM_COST = 320;
    public static final int GOLD_COST = 280;
    public static final int SILVER_COST = 240;
    public static final double SERVICE_TAX_RATE = 0.14;
    public static final double SWACHH_BHARAT_CESS_RATE = 0.005;
    public static final double KRISHI_KALYAN_CESS_RATE = 0.005;

    public static int[][] platinumSeats = new int[3][10]; 
    public static int[][] goldSeats = new int[3][10];
    public static int[][] silverSeats = new int[3][10];

    public static int revenue = 0; 
    public static double serviceTax = 0; 
    public static double swachhBharatCess = 0; 
    public static double krishiKalyanCess = 0; 


}
