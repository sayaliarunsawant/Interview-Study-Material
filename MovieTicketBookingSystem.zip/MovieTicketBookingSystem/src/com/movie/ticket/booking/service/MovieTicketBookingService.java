package com.movie.ticket.booking.service;

import java.util.Scanner;

import movie.ticket.booking.util.MovieTicketBookingUtil;

public class MovieTicketBookingService {

	private static Scanner sc = new Scanner(System.in);

	public static void main(String[] args) {
		showAvailableSeats();
		bookTickets();
		printTotalRevenue();
	}

	public static void showAvailableSeats() {
		System.out.println("Available Seats:");
		System.out.println("Platinum: ");
		displaySeats(MovieTicketBookingUtil.platinumSeats);
		System.out.println("Gold: ");
		displaySeats(MovieTicketBookingUtil.goldSeats);
		System.out.println("Silver: ");
		displaySeats(MovieTicketBookingUtil.silverSeats);
	}

	public static void displaySeats(int[][] seats) {
		for (int i = 0; i < seats.length; i++) {
			System.out.print("Row " + (char) ('A' + i) + ": ");
			for (int j = 0; j < seats[i].length; j++) {
				if (seats[i][j] == 0) {
					System.out.print((j + 1) + " ");
				} else {
					System.out.print("X ");
				}
			}
			System.out.println();
		}
	}

	public static void bookTickets() {
		System.out.println("Enter show number (1, 2, or 3): ");
		int showNumber = sc.nextInt();
		sc.nextLine();

		System.out.println("Enter seat category (Platinum, Gold, or Silver): ");
		String category = sc.nextLine();

		int[][] seats = null;
		int seatCost = 0;
		switch (category) {
		case "Platinum":
			seats = MovieTicketBookingUtil.platinumSeats;
			seatCost = MovieTicketBookingUtil.PLATINUM_COST;
			break;
		case "Gold":
			seats = MovieTicketBookingUtil.goldSeats;
			seatCost = MovieTicketBookingUtil.GOLD_COST;
			break;
		case "Silver":
			seats = MovieTicketBookingUtil.silverSeats;
			seatCost = MovieTicketBookingUtil.SILVER_COST;
			break;
		default:
			System.out.println("Invalid category! Please try again.");
			bookTickets();
			return;
		}

		System.out.println("Enter row (A, B, or C): ");
		char row = sc.nextLine().toUpperCase().charAt(0);

		System.out.println("Enter seat number (1-10): ");
		int seatNumber = sc.nextInt();

		if (seats[row - 'A'][seatNumber - 1] == 0) {
			seats[row - 'A'][seatNumber - 1] = 1; // Mark seat as booked

			// Calculate total cost and taxes
			int totalCost = seatCost;
			double totalTax = seatCost * (MovieTicketBookingUtil.SERVICE_TAX_RATE
					+ MovieTicketBookingUtil.SWACHH_BHARAT_CESS_RATE + MovieTicketBookingUtil.KRISHI_KALYAN_CESS_RATE);

			// Update total revenue and taxes
			MovieTicketBookingUtil.revenue += totalCost;
			MovieTicketBookingUtil.serviceTax += totalTax;
			MovieTicketBookingUtil.swachhBharatCess += totalTax;
			MovieTicketBookingUtil.krishiKalyanCess += totalTax;

			System.out.println("Seat booked successfully!");
			System.out.println("Total Cost: Rs. " + totalCost);
			System.out.println("Service Tax: Rs. " + (seatCost * MovieTicketBookingUtil.SERVICE_TAX_RATE));
			System.out
					.println("Swachh Bharat Cess: Rs. " + (seatCost * MovieTicketBookingUtil.SWACHH_BHARAT_CESS_RATE));
			System.out
					.println("Krishi Kalyan Cess: Rs. " + (seatCost * MovieTicketBookingUtil.KRISHI_KALYAN_CESS_RATE));
		} else {
			System.out.println("Seat not available! Please try again.");
			bookTickets();
		}
	}

	public static void printTotalRevenue() {
		System.out.println("Total Revenue: Rs. " + MovieTicketBookingUtil.revenue);
		System.out.println("Service Tax: Rs. " + MovieTicketBookingUtil.serviceTax);
		System.out.println("Swachh Bharat Cess: Rs. " + MovieTicketBookingUtil.swachhBharatCess);
		System.out.println("Krishi Kalyan Cess: Rs. " + MovieTicketBookingUtil.krishiKalyanCess);
	}

}
