package com.movie.ticket.booking.main;

import com.movie.ticket.booking.service.MovieTicketBookingService;

public class MovieTicketBooking {

	public static void main(String[] args) {

		MovieTicketBookingService.showAvailableSeats();

		MovieTicketBookingService.bookTickets();

		MovieTicketBookingService.printTotalRevenue();

	}

}